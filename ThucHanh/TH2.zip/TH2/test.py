import csv


plainText = "The treasure is under the coconut tree"
print(plainText.encode('utf-8'))
